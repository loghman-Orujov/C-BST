#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define MAX_STACK_SIZE 100//bir stack yap�s�nda bulunabilecek max eleman say�s�

//a�a� yap�s�n� tan�mlamak ad�na kullan�lacak struct yap�s�
typedef struct Node {
    int data;
    struct Node* left;
    struct Node* right;
} Node;

//a�a� yap�s�ndaki d���mlerde yer alan data bilgisini ekleme fonksiyonu
Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

//bu a�a� yap�s�n� bst format�na getiren fonksiyon
Node* insert(Node* root, int data) {
    if (root == NULL) {
        return createNode(data);
    } else if (data <= root->data) {
        root->left = insert(root->left, data);
    } else {
        root->right = insert(root->right, data);
    }
    return root;
}

//herhangi bir d���m� silmek ad�na kullan�lan fonksiyon
Node* delete(Node* root, int data) {
    if (root == NULL) {
        return root;
    } else if (data < root->data) {
        root->left = delete(root->left, data);
    } else if (data > root->data) {
        root->right = delete(root->right, data);
    } else {
        if (root->left == NULL) {
            Node* temp = root->right;
            free(root);
            return temp;
        } else if (root->right == NULL) {
            Node* temp = root->left;
            free(root);
            return temp;
        }
        Node* temp = root->right;
        while (temp->left != NULL) {
            temp = temp->left;
        }
        root->data = temp->data;
        root->right = delete(root->right, temp->data);
    }
    return root;
}

//at��lar sonras� ii�in g�ncelleme yapan fonksiyon
Node* updateOrDelete(Node* root, int k, int p, int* stack, int* top) {
    if (root == NULL) {
        return root;
    } 
	else if (root->data == k) {
        if (p < root->data) {
            root->data -= p;
        } else {
            if (*top < MAX_STACK_SIZE) { // stack dolu de�ilse
                stack[(*top)++] = root->data; // veri stack'e eklenir
            }
            root = delete(root, k);
        }
    } else if (k < root->data) {
        root->left = updateOrDelete(root->left, k, p, stack, top);
    } else {
        root->right = updateOrDelete(root->right, k, p, stack, top);
    }
    return root;
}

//a�a� yap�s�n� inorder olarak dola�an fonksiyon
void inorder(Node* root) {
    if (root != NULL) {
        inorder(root->left);
        printf("%d ", root->data);
        inorder(root->right);
    }
}

//stack yap�s�ndaki de�erleri ekrana yazd�ran fonksiyon
void printStack(int* stack, int top) {
	int i;
    printf("Deleted nodes: ");
    for ( i = top -1; i >= 0; i--) {
        printf("%d ", stack[i]);
    }
    printf("\n");
}

//stackden en �stten ba�layarak stack yap�s�na uygun �ekilde eleman ��karan fonksiyon
void push(int stack[], int *top, int value) {
    if (*top == MAX_STACK_SIZE-1) {
        printf("Stack overflow!\n");
        return;
    }
    stack[(*top)++] = value;
  
}

//stack yap�s�na uygun bir formatta stack e eleman ekleyen fonksiyon
int pop(int stack[], int *top) {
    if (*top == -1) {
        printf("Stack is empty!\n");
        return -1;
    }
    return stack[(*top)--];
}

// A�ac� postorder traversal ile serbest b�rakma fonksiyonu
void freeBST(Node* root) {
    if (root != NULL) {
        freeBST(root->left);
        freeBST(root->right);
        free(root);
    }
}

int main() {
	int stack[MAX_STACK_SIZE];
	int empty_stack[MAX_STACK_SIZE];
    int top = 0,top2=0,temp,temp2;
    Node* root = NULL;
    srand(time(NULL)); // rastgele say� �retmek i�in seed de�eri atan�r
    int N, M, k, p, i,j,check,control,data;
    int dizi[MAX_STACK_SIZE];//a�a�ta yer alan d���mlerdeki data bilgisinin birbirinden farkl� olmas� ad�na olu�turuldu
    
    control=1;
    while(control==1){
    printf("Enter the value of M: ");
    scanf("%d", &M); // A�a�ta kullan�lacak say� miktar� al�n�r
    if(M>MAX_STACK_SIZE || M<3 )
    printf("This value is wrong. Please re-enter");
    else
    control=0;
	}
    control=1;
    while(control==1){
    printf("Enter the value of N: ");
    scanf("%d", &N); // A�a�ta kullan�lacak say� miktar� al�n�r
    if(N>1000 || N<M )
    printf("This value is wrong. Please re-enter");
    else
    control=0;
	}

    
    for (i = 0; i < M; i++) {
        control = 1;
        while (control == 1) {
            data = rand() % N + 1; // 1...N aras�nda rastgele say� �retilir
            dizi[i] = data;
            check = 1;
            j = 0;
            while (check == 1 && j < i) {
                if (dizi[j] != data) {
                    j++;
                } else {
                    check = 0;
                }
            }
            if (check == 1) {
                control = 0;
            }
        }
        root = insert(root, data); // �retilen say� a�aca eklenir
    }

    printf("BST tree: ");
    inorder(root);
    printf("\n");

while(root!=NULL){
    printf("Enter the value k: ");
    scanf("%d",&k);
    printf("Enter the value p: ");
    scanf("%d",&p);

    root = updateOrDelete(root, k, p, stack, &top);

    printf("New BST tree: ");
    inorder(root);
    printf("\n");
}

temp2=top;
top--;
while(top2!=temp2){
	temp=pop(stack,&top);
	push(empty_stack,&top2,temp);
}

printStack(empty_stack,top2);

freeBST(root);

    return 0;
}
